---
name: Feature request
about: Suggest new education materials
title: ''
labels: ''
assignees: ''

---

**Is your feature request related to a learning material?**
Please add the topics/arguments which you would like better to discuss or should be improved/reviewed.

**Additional context**
Add any other context or screenshots about the feature request here.
